#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_RUNNER
#include "catch.hpp"


#include "../FileUtil.h"



FileUtil fu;

TEST_CASE("Parking Cost-3.0"){
   // FileUtil::getPartkingCost(double parkingDuration)
    REQUIRE(3.0==fu.getPartkingCost(1.5));
}
TEST_CASE("parking cost 00"){
   // FileUtil::getPartkingCost(double parkingDuration)
    REQUIRE(00==fu.getPartkingCost(0));
}


TEST_CASE("Check tokenization"){
   std::vector<std::string> tk =fu.getStringToken("AP22B4414|0:05:20|-");
    REQUIRE(tk[0]=="AP22B4414");
}