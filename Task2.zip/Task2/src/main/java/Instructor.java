
public class Instructor {
	private int id;
	private String name;
	private Member novice;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Member getNovice() {
		return novice;
	}

	public void setNovice(Member novice) {
		this.novice = novice;
	}

}
